The program BMCP_IHS contains two input parameters: InsName TimeLimit (600s).

Keep the program and the benchmark instances in the same folder.

Then the job can be subbmitted as follows:
————————————————————————————————————————
./BMCP_IHS   InsName   TimeLimit 
————————————————————————————————————————

The results are stored in the text file named "InsName_result.txt".
