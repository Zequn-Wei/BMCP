The program BMCP_IHS contains two input parameters: InsName seed.

The cut-off time is set to 600 seconds.

Keep the program and the benchmark instances in the same folder.

Then the job can be subbmitted as follows:
————————————————————————————————————————
./BMCP_IHS   InsName   seed 
————————————————————————————————————————

The results are stored in the text file named "InsName_result.txt".
